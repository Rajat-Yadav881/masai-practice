package com.example.geektrust.model;

public class StaticCharges {
	public static final Integer ADULT_CHARGE = 100;
	public static final Integer KID_CHARGE = 50;
	public static final Integer SENIORCITIZEN_CHARGE = 200;
}
