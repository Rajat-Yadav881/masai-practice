package com.example.geektrust.service;

import java.util.List;

import com.example.geektrust.model.Command;

public class ExecutionServiceImpl implements ExecutionService{

	@Override
	public String runCommandFile(List<Command> arguments) {
		String output="";
		for (Command input : arguments) {
			
			//validate incoming input 
			InputChecksImpl inputCheck=new InputChecksImpl();
			inputCheck.commandChecks(input);
			
			if (input.getCommand().equals("BALANCE")) {
				initializeBalance(input.getToken());
			} else if (input.getCommand().equals("CHECK_IN")) {
				processCheckIn(input.getToken());
			} else if (input.getCommand().equals("PRINT_SUMMARY")) {
				output= printSummary();
				System.out.print(output);
			} else {
				throw new ProcessingException("Invalid Input Commands, please check the input command.");
			}
		}
		return output;
	}

}
