package com.students.service;


import com.students.model.Semester;

public interface SemesterService {
	public Semester addSemester(String email,Semester semester);
	
}
