import nav__bar from "../../component/navbar.js"

import foot_er from "../../component/footer.js"

document.querySelector(".nav_bar_section").innerHTML = nav__bar();

document.getElementById("last_part_footer").innerHTML = foot_er();