let nav__bar = ()=>{
    return `
            <div class="cont_ner">
            <a class="navbar_brand_click" href="index.html"><img src="https://cdn-m.timecamp.com/img/greenbranding/colorLogo.svg"></a>
            <div id="dashboard_set">
            <ul class="navbar_nav">
            <li class="navbar_ul_li"><a href='../homepage/index.html' style="color:#1b1b20">Features</a></li>
            <li class="navbar_ul_li"><a href='../pricing/pricing.html' style="color:#1b1b20">Pricing</a></li>
            <li class="navbar_ul_li"><a href='../integration/integration.html' style="color:#1b1b20">Integration</a></li>
            <li class="navbar_ul_li"><a href='../blogpage/blog.html' style="color:#1b1b20">Blog</a></li>
            </ul>
            <ul class="navbar_nav">
            <li class="navbar_ul_li"><a href='#' style="color:#1b1b20">Book a Demo</a></li>
            <li class="vl"></li>
            <li class="navbar_ul_li"><a href='../signup/signup.html' style="color:#1b1b20">Sign in</a></li>
            
            <li class="navbar_ul_li" id="Zbutton" ><a href='#' style="color:#fff">Go to App</a></li>           
            </ul>
            </div>
            </div>
            
            `
}
export default nav__bar;
