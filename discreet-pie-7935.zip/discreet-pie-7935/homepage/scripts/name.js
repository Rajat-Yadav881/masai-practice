
let data = JSON.parse(localStorage.getItem("key1"))

function show(){
    
}