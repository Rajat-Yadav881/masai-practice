package com.students;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsReportingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentsReportingSystemApplication.class, args);
	}

}
