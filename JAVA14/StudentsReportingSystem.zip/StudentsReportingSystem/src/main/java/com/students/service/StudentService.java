package com.students.service;



import com.students.model.Student;

public interface StudentService {
	public Student addStudent(Student student);
	
}
