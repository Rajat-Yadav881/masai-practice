package com.example.geektrust.controller;

import java.util.List;

import com.example.geektrust.model.Command;

public class InputChecksImpl implements InputChecks{
	
	@Override
	public void commandChecks(Command inputCommand) {
		String command=inputCommand.getCommand();
		if(command.equals("BALANCE")) {
			commandBalanceCheck(inputCommand.getToken());
		}
		else if(command.equals("CHECK_IN")) {
			commandCheckInCheck(inputCommand.getToken());
		}
		else if(command.equals("PRINT_SUMMARY")) {
			commandPrintSummaryCheck(inputCommand.getToken());
		}
		else {
	
			break;
		}
		
	}
	
	public void commandBalanceCheck(List<String> tokens) {
		if(tokens.size()!=2) {
			
		}
		Integer balance = Integer.parseInt(tokens.get(1));
		if(balance<0) {
			
		}
	}
}
