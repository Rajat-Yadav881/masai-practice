let automobile={
    brand :"TATA",
    wheel : 4,
    seats : 5,
    gear : "manual"
 
}


let car1 = Object.create(automobile)
car1.name = "Tiago"
car1.model = "petrol"
let car2 = Object.create(automobile)
car2.name = "zest"
car2.model = "CNG"
let car3 = Object.create(automobile)
car3.name = "safari"
car3.model = "petrol"
let vechicle=[car1,car2,car3]
console.log("vechicle:",vechicle)
let bag = ""
vechicle.forEach((el)=>{
    let x = `${el.name} is ${el.gear} which is ${el.seats}`
    bag += x+"\n"+" "
    
})
document.getElementById("container").innerHTML = bag
