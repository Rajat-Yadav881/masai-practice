import foot_er from "../component/footer.js";

let footer=document.getElementById("footer");
footer.innerHTML=foot_er();