package com.example.geektrust.controller;


import com.example.geektrust.model.InputCommands;

public interface InputChecks {

	public void commandChecks(InputCommands inputCommand) ;
}
