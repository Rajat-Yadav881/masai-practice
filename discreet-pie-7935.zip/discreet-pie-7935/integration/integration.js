import nav__bar from "../component/navbar.js"

import foot_er from "../component/footer.js"


let nav =document.querySelector(".nav_bar_section");
let foot =document.getElementById("last_part_footer");
nav.innerHTML=nav__bar();
foot.innerHTML=foot_er();