package com.example.geektrust.controller;

import com.example.geektrust.model.Command;

public interface InputChecks {
	public void commandChecks(Command command);
}
