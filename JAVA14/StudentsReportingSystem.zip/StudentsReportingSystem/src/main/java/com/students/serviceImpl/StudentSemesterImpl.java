package com.students.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.students.model.Student;
import com.students.service.StudentSemesterService;
@Service
public class StudentSemesterImpl implements StudentSemesterService{

	@Override
	public double getAveragePercentageOfRecentSemester() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getAverageMarksInSubject(String subject) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Student> getTop2ConsistentStudents() {
		// TODO Auto-generated method stub
		return null;
	}

}
